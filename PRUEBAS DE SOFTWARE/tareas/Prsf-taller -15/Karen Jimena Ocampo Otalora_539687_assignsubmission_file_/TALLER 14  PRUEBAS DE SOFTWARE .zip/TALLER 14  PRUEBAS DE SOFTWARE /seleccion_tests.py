# seleccion_tests.py
"""
Parte 3 - Diseño por Programación Dinámica (DP) aplicado.
Selección óptima de tests para un pipeline CI con presupuesto de tiempo.

Ejecutar:
    python seleccion_tests.py
"""
from typing import List, Tuple


# ---------------------------------------------------------------------------
# Datos del taller
# ---------------------------------------------------------------------------
TESTS: List[Tuple[str, int, int]] = [
    ("test_login",              3, 85),
    ("test_calculo_promedio",   5, 95),
    ("test_deteccion_riesgo",   4, 90),
    ("test_exportar_pdf",       6, 70),
    ("test_exportar_excel",     5, 75),
    ("test_api_reportes",       3, 80),
    ("test_prediccion",         8, 65),
    ("test_ui_dashboard",       7, 60),
    ("test_concurrency",        9, 55),
    ("test_seguridad",          4, 88),
]


# ---------------------------------------------------------------------------
# 3.2  Knapsack 0/1 (DP exacto)
# ---------------------------------------------------------------------------
def seleccionar_tests_optimos(tests, presupuesto):
    """
    tests: [(nombre, tiempo, valor), ...]
    presupuesto: int (minutos disponibles)

    Retorna (valor_total, lista_tests_seleccionados)
    """
    n = len(tests)
    # dp[i][w] = mejor valor usando los primeros i tests con presupuesto w
    dp = [[0] * (presupuesto + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        nombre, tiempo, valor = tests[i - 1]
        for w in range(presupuesto + 1):
            # No tomar el test i
            dp[i][w] = dp[i - 1][w]
            # Tomar el test i (si cabe)
            if tiempo <= w:
                candidato = dp[i - 1][w - tiempo] + valor
                if candidato > dp[i][w]:
                    dp[i][w] = candidato

    # Reconstrucción de la solución
    seleccionados = []
    w = presupuesto
    for i in range(n, 0, -1):
        if dp[i][w] != dp[i - 1][w]:
            nombre, tiempo, valor = tests[i - 1]
            seleccionados.append(tests[i - 1])
            w -= tiempo
    seleccionados.reverse()

    return dp[n][presupuesto], seleccionados


# ---------------------------------------------------------------------------
# Comparativa: Greedy por ratio valor/tiempo
# ---------------------------------------------------------------------------
def seleccionar_tests_greedy(tests, presupuesto):
    """Heurística: ordena por ratio valor/tiempo descendente y va llenando."""
    ordenados = sorted(tests, key=lambda t: t[2] / t[1], reverse=True)
    seleccionados = []
    tiempo_usado = 0
    valor_total = 0
    for nombre, tiempo, valor in ordenados:
        if tiempo_usado + tiempo <= presupuesto:
            seleccionados.append((nombre, tiempo, valor))
            tiempo_usado += tiempo
            valor_total += valor
    return valor_total, seleccionados


# ---------------------------------------------------------------------------
# Reporte
# ---------------------------------------------------------------------------
def imprimir_resultado(titulo, valor_total, seleccionados):
    tiempo_usado = sum(t for _, t, _ in seleccionados)
    print(f"\n=== {titulo} ===")
    print(f"Valor total      : {valor_total}")
    print(f"Tiempo usado     : {tiempo_usado} min")
    print("Tests elegidos   :")
    for nombre, tiempo, valor in seleccionados:
        print(f"  - {nombre:<25}  tiempo={tiempo}  valor={valor}")


if __name__ == "__main__":
    PRESUPUESTO = 25

    valor_dp, sel_dp = seleccionar_tests_optimos(TESTS, PRESUPUESTO)
    valor_g,  sel_g  = seleccionar_tests_greedy(TESTS, PRESUPUESTO)

    imprimir_resultado("DP (Knapsack 0/1) - ÓPTIMO", valor_dp, sel_dp)
    imprimir_resultado("GREEDY (ratio valor/tiempo)", valor_g, sel_g)

    diff_pct = (valor_dp - valor_g) / valor_dp * 100 if valor_dp else 0
    print(f"\nDiferencia DP vs Greedy: {valor_dp - valor_g} puntos "
          f"({diff_pct:.2f} %)")

    set_dp = {t[0] for t in sel_dp}
    set_g  = {t[0] for t in sel_g}
    print(f"Solo en DP    : {sorted(set_dp - set_g)}")
    print(f"Solo en Greedy: {sorted(set_g - set_dp)}")
