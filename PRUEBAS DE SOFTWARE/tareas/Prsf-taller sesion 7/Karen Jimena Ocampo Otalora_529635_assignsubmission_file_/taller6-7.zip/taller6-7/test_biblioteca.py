
import pytest
import requests

BASE = 'http://localhost:8000/api'

def test_smoke_api_disponible():
    # test basico de humo
    assert True

def test_regression_prestamo():
    # test de regresion
    assert True
