
Feature: Sistema de multas por devolucion tardia

  Scenario: Calculo de multa por 3 dias de retraso
    Given que el estudiante tiene un libro con 3 dias de retraso
    When el sistema procesa la devolucion
    Then el monto de la multa debe ser "$1500 COP"
